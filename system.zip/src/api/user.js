//登录
import request from "@/utils/request.js";
//url 地址：http://www.yinruifang.cn/index/Api/login
export function Login(data) {
  return request({
    url: "login",
    method: "post",
    data: data,
  });
}
