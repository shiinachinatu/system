<template>
  <div>超级管理员页面</div>
</template>

<script>
export default {
  name: "super",
};
</script>

<style>
</style>