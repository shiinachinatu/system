// 1.引入 axios
import axios from "axios";
import { Message } from "element-ui";
//引入cookie
import { getCookie } from "@/utils/support.js";
const apiurl = process.env.VUE_APP_API_URL;
console.log(apiurl);
console.log(process.env.NODE_ENV);
// 2.创建 axios 实例
const service = axios.create({
  // 3.配置
  //baseURL  后三个字母是大写
  // baseURL: "http://www.yinruifang.cn/index/Api", //请求的基础路径
  baseURL: apiurl + "/index/Api", //请求的基础路径
  timeout: 60 * 60 * 1000, //请求的超时时间
});

// 4.请求拦截

service.interceptors.request.use(
  (config) => {
    //设置 token
    config.headers.Authorization = getCookie("token"); //token  代表从后台传过来的token的令牌
    return config;
  },
  (err) => {
    return Promise.reject(err);
  }
);

// 5.响应拦截
service.interceptors.response.use(
  (res) => {
    // console.log(res,"-----From utils");
    const data = res.data;
    //如果后台返回的报错码和报错信息的话
    if (data.status !== 200) {
      Message({
        type: "error",
        message: data.msg,
        duration: 2000,
      });
    } else {
      return data;
    }
  },
  (err) => {
    console.log(err);
    Message({
      type: "error",
      message: err,
      duration: 2000,
    });
  }
);

// 6.导出
export default service;
