import router from "./router";
import { getCookie } from "@/utils/support.js";
import Store from "./store";
import { Message } from "element-ui";

//守卫
/*
beforeEach 里面是一个函数 ，这个函数中有三个参数  to  from   next
*/
/*
登录页不需要守卫，
如果没有登录 ，跳转 登录页
如果已经登录 ，放行
*/
const whileList = ["/login"];
router.beforeEach((to, from, next) => {
  // console.log(whileList.indexOf(to.path), "このメッセージbeforEach");
  // console.log(getCookie("token"), "token");
  // 第一个if判断token是否有值，没登录执行else 进入判断whileLisi
  if (getCookie("token")) {
    if (to.path == "/login") {
      next("/home");
    } else if (to.path == "/super") {
      if (getCookie("roleid") == 1) {
        next();
      } else {
        Message({
          message: "您没有权限访问该页面,请退出后使用 【超级管理员】 身份登录",
          type: "err",
          duration: 2000,
        });
        Store.dispatch("LOGOUT_AC");
        router.go(0);
      }
    } else {
      next();
    }
  } else {
    // 判断是否在登录状态
    if (whileList.indexOf(to.path) !== -1) {
      next();
    } else {
      next("/login");
    }
  }
});
