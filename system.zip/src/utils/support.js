import Cookie from "js-cookie";

export function setCookie(key, value, expires) {
  return Cookie.set(key, value, { expires: expires });
}

export function getCookie(key) {
  return Cookie.get(key);
}
export function removeCookie(key) {
  return Cookie.remove(key);
}
