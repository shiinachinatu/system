<template>
  <div class="mymenu">
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b"
      :collapse="!sidebar.opened"
    >
      <el-menu-item index="/home">
        <i class="iconfont icon-home"></i>
        <span>首页</span>
      </el-menu-item>

      <router-link to="/super" v-if="roleid == 1">
        <el-menu-item index="/super">
          <i class="iconfont icon-liebiao1"></i>
          <span>超级管理员</span>
        </el-menu-item>
      </router-link>

      <el-submenu index="2">
        <template slot="title">
          <i class="iconfont icon-shangpin-tianchong"></i>
          <span>商品</span>
        </template>

        <el-menu-item-group>
          <router-link to="/pms/product">
            <el-menu-item index="/pms/product">
              <i class="iconfont icon-liebiao1"></i>
              <span>商品列表</span>
            </el-menu-item>
          </router-link>

          <router-link to="/pms/productadd">
            <el-menu-item index="/pms/productadd">
              <i class="iconfont icon-tianjia"></i>
              <span>添加商品</span>
            </el-menu-item>
          </router-link>

          <router-link to="/pms/productCate">
            <el-menu-item index="/pms/productCate">
              <i class="iconfont icon-fenlei1"></i><span> 商品分类</span>
            </el-menu-item>
          </router-link>

          <router-link to="/pms/productAttr">
            <el-menu-item index="/pms/productAttr">
              <i class="iconfont icon-fenlei"></i>
              <span>商品管理</span>
            </el-menu-item>
          </router-link>

          <router-link to="/pms/brand">
            <el-menu-item index="/pms/brand">
              <i class="iconfont icon-pinpaitemai"></i>
              <span>品牌管理</span>
            </el-menu-item>
          </router-link>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "Sidebar",
  mounted() {
    // console.log(this.$route.path);
  },
  methods: {
    handleOpen: function () {
      // console.log("菜单打开了");
    },
    handleClose: function () {
      // console.log("菜单关闭了");
    },
  },
  computed: {
    ...mapGetters(["sidebar", "roleid"]),
  },
};
</script>

<style scoped lang='scss'>
.mymenu {
  .el-menu {
    border-right: none;
  }
}
</style>