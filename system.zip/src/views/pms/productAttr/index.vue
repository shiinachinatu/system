<template>
  <div>
    商品类型
    <div>
      
    </div>
    <el-table :data="attrList" border style="width: 100%">
      <el-table-column prop="id" label="编号" width="180"> </el-table-column>
      <el-table-column prop="name" label="类型名称" width="180">
      </el-table-column>
      <el-table-column prop="attribute_count" label="属性数量">
      </el-table-column>
      <el-table-column prop="param_count" label="参数数量"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="primary" size="small"
            >编辑</el-button
          >
          <el-button
            type="error"
            size="small"
            @click="delProductAttr(scope.row.id)"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
//引入 商品类型的  获取数据的 函数
import { fetchProductAttrList, delProductAttr } from "@/api/product.js";
export default {
  name: "productAttr",
  data: function () {
    return {
      attrList: [],
    };
  },
  created() {
    //获取数据
    this.getProductAttrList();
  },
  methods: {
    //编辑的函数
    handleClick(row) {
      console.log(row);
    },
    getProductAttrList() {
      fetchProductAttrList().then((res) => {
        console.log(res);
        this.attrList = res.data;
      });
    },
    delProductAttr(id) {
      console.log(id);
      // console.log(this.scope.row.id);
      //1.删除前需要提示
      this.$confirm("此操作将永久删除该条商品数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          delProductAttr({ id: id }).then((res) => {
            // console.log(res);
            if (res.type == "success") {
              this.$message({
                type: "success",
                message: "删除成功!",
                duration: 2000,
              });
              //2.删除后需要刷新数据
              //重新获取数据
              this.getProductAttrList();
              // this.getProductList();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
            duration: 2000,
          });
        });
    },
  },
};
</script>

<style>
</style>