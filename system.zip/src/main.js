import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
// 引入 element ui框架
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import "./assets/fonts/iconfont.css";
// echarts
import * as echarts from "echarts";
// 路由守卫
import "./permission.js";
Vue.prototype.$echarts = echarts;

Vue.config.productionTip = false;

Vue.use(ElementUI);

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
