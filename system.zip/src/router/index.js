import Vue from "vue";
import VueRouter from "vue-router";
import Layout from "../views/layout/index.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "home",
    component: Layout,
    redirect: "/home",
    children: [
      {
        path: "home",
        meta: { title: "首页" },
        name: "home",
        component: () =>
          import(/* webpackChunkName: "home" */ "../views/home/index.vue"),
      },
      {
        path: "super",
        meta: { title: "管理员页面" },
        name: "super",
        component: () =>
          import(/* webpackChunkName: "super" */ "../views/super/index.vue"),
      },
    ],
  },
  {
    path: "/pms",
    name: "pms",
    meta: { title: "商品" },
    component: Layout,
    redirect: "/pms/product",
    children: [
      {
        path: "product",
        meta: { title: "商品列表" },
        name: "product",
        component: () =>
          import(
            /* webpackChunkName: "product" */ "../views/pms/product/index.vue"
          ),
      },
      {
        path: "productadd",
        meta: { title: "添加商品" },
        name: "productadd",
        component: () =>
          import(
            /* webpackChunkName: "productadd" */ "../views/pms/product/add.vue"
          ),
      },
      {
        path: "updateProductCate/:id",
        meta: { title: "修改商品分类" },
        name: "updateProductCate",
        component: () =>
          import(
            /* webpackChunkName: "productcateupdate" */ "../views/pms/productCate/update.vue"
          ),
      },
      {
        path: "productCate",
        meta: { title: "商品分类列表" },
        name: "productCate",
        component: () =>
          import(
            /* webpackChunkName: "productCate" */ "../views/pms/productCate/index.vue"
          ),
      },
      {
        path: "productCateAdd",
        meta: { title: "添加商品分类" },
        name: "productCateAdd",
        component: () =>
          import(
            /* webpackChunkName: "productCateAdd" */ "../views/pms/productCate/add.vue"
          ),
      },
      {
        path: "productupdate/:id",
        meta: { title: "商品类型列表" },
        name: "productupdate",
        component: () =>
          import(
            /* webpackChunkName: "productupdate" */ "../views/pms/product/update.vue"
          ),
      },
      {
        path: "productAttr",
        meta: { title: "商品类型列表" },
        name: "productAttr",
        component: () =>
          import(
            /* webpackChunkName: "productAttr" */ "../views/pms/productAttr/index.vue"
          ),
      },
      {
        path: "brand",
        meta: { title: "商品品牌列表" },
        name: "brand",
        component: () =>
          import(
            /* webpackChunkName: "brand" */ "../views/pms/brand/index.vue"
          ),
      },
    ],
  },

  {
    path: "/login",
    name: "Login",
    component: () =>
      import(/* webpackChunkName: "login" */ "../views/login/index.vue"),
  },
  {
    path: "*",
    component: () =>
      import(/* webpackChunkName: "page404" */ "../views/page404/index.vue"),
  },
];

const router = new VueRouter({
  routes,
});

export default router;
