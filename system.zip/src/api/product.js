import request from "@/utils/request.js";
//获取商品列表
export function fetchProductList(params) {
  return request({
    url: "product_list",
    method: "get",
    params: params,
  });
}

export function fetchProductAttrList(params) {
  return request({
    url: "get_product_attr",
    method: "get",
    params: params,
  });
}

export function fetchProductCateList(params, parent_id) {
  return request({
    url: "get_product_category_list/" + parent_id, //从 后台api里面查找
    method: "get",
    params: params,
  });
}
export function fetchBrandList(params) {
  return request({
    url: "get_product_brand_pag", //从 后台api里面查找
    method: "get",
    params: params,
  });
}
export function fetchBrand(params) {
  return request({
    url: "get_product_brand",
    method: "get",
    params: params,
  });
}
export function fetchCategory(params) {
  return request({
    url: "get_product_category",
    method: "get",
    params: params,
  });
}
//添加商品列表接口
export function createProduct(data) {
  return request({
    url: "create_product",
    method: "post",
    data: data,
  });
}

//添加商品分类接口
//：http://www.yinruifang.cn/index/Api/create_product_cate
export function createProductCate(data) {
  return request({
    url: "create_product_cate",
    method: "post",
    data: data,
  });
}

//修改商品信息
//http://www.yinruifang.cn/index/Api/update_product
export function updateProduct(data) {
  return request({
    url: "update_product",
    method: "post",
    data: data,
  });
}

//通过id获取一条商品记录
//url 地址：http://www.yinruifang.cn/index/Api/product_one
export function getProductOne(params) {
  return request({
    url: "product_one",
    method: "get",
    params: params,
  });
}
//通过 id删除 商品数据
//http://www.yinruifang.cn/index/Api/delete_status
export function delProduct(params) {
  return request({
    url: "delete_status",
    method: "get",
    params: params,
  });
}

//删除商品分类
// http://www.yinruifang.cn/index/Api/delete_category
export function delCategory(data) {
  return request({
    url: "delete_category",
    method: "post",
    data: data,
  });
}

//删除商品类型
// http://www.yinruifang.cn/index/Api/delete_product_attr
export function delProductAttr(params) {
  return request({
    url: "delete_product_attr",
    method: "get",
    params: params,
  });
}

//修改商品分类
//http://www.yinruifang.cn/index/Api/update_product_cate
export function updateProductCate(data) {
  return request({
    url: "update_product_cate",
    method: "post",
    data: data,
  });
}
//获取一条商品分类信息
//http://www.yinruifang.cn/index/Api/product_cate_one
export function productCateOne(params) {
  return request({
    url: "product_cate_one",
    method: "get",
    params: params,
  });
}
