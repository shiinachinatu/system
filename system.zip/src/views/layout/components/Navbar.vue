<template>
  <div class="navbar-con">
    <div class="navbar-left">
      <i
        class="iconfont icon-hanbaobao hbb"
        :class="{ 'is-active': !sidebar.opened }"
        @click="changeSidebar"
      ></i
      ><myBreadcrumb></myBreadcrumb>
    </div>
    <div class="navbar-xiala">
      <span
        >欢迎
        <p class="User-Name">{{ name }}</p>
        登录后台管理系统</span
      >
      <el-dropdown>
        <span class="el-dropdown-link">
          <img src="@/assets/images/mz_small_icon.png" />
          <i class="el-icon-arrow-down el-icon--right"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item
            ><router-link to="/">首页</router-link></el-dropdown-item
          >
          <el-dropdown-item @click.native="logout">退出</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
import myBreadcrumb from "@c/myBreadcrumb/index.vue";
import { mapGetters } from "vuex";
export default {
  name: "Navbar",
  components: {
    myBreadcrumb,
  },
  computed: {
    ...mapGetters(["sidebar", "name"]),
  },
  methods: {
    changeSidebar() {
      this.$store.dispatch("TOGGLE_SIDEBAR_AC");
    },
    logout() {
      this.$store.dispatch("LOGOUT_AC");
      //页面刷新，0是刷新 1是首页
      // 另一种写法 js源生 location.reload();
      this.$router.go(0);
      console.log('click---logout');
    },
  },
};
</script>

<style scoped lang="scss">
.navbar-con {
  display: flex;
  justify-content: space-between;
  flex-wrap: nowrap;
  .navbar-left {
    display: flex;
    margin-left: 20px;
    .icon-hanbaobao {
      margin-right: 10px;
    }
    .hbb {
      transform: rotate(0deg);
      transition: 1s;
      transform-origin: 50% 50%;
    }
    .is-active {
      transform: rotate(90deg);
    }
  }
  .navbar-xiala {
    img {
      width: 45px;
      margin-top: 2px;
    }
    .User-Name {
      color: red;
      display: inline;
    }
  }
}
</style>