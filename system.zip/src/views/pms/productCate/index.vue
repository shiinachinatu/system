<template>
  <div class="pro_con">
    <el-card class="box-card">
      <div class="clearfix">
        <i class="iconfont icon-icon-test"></i>
        <span> 商品分类列表</span>
        <el-button
          style="float: right"
          type="primary"
          size="mini"
          @click="goAdd"
          >添加</el-button
        >
        <el-button
          class="goBack"
          style="float: right"
          type="primary"
          size="mini"
          v-if="parent_id != 0"
          @click="goParentLevel"
          >返回</el-button
        >
      </div>
    </el-card>

    <el-table :data="cateList" border style="width: 100%">
      <el-table-column prop="id" label="编号" width="180"> </el-table-column>
      <el-table-column prop="name" label="类型名称" width="180">
      </el-table-column>
      <el-table-column label="级别">
        <template slot-scope="scope">
          {{ scope.row.level | levelF }}
        </template>
      </el-table-column>
      <el-table-column prop="product_count" label="商品数量"> </el-table-column>
      <el-table-column prop="product_unit" label="数量单位"> </el-table-column>
      <el-table-column label="是否显示">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.show_status"
            :active-value="1"
            :inactive-value="0"
          >
          </el-switch>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            @click="showNextLevel(scope.row.id)"
            size="mini"
            :disabled="scope.row.level != 0"
            >查看下级</el-button
          >
        </template>
      </el-table-column>

      <el-table-column label="操作" width="180">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            @click="updateProductCate(scope.row.id)"
            >编辑</el-button
          >
          <el-button
            type="danger"
            size="mini"
            @click="delCategory(scope.row.id)"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      :page-size="listQuery.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    >
    </el-pagination>
  </div>
</template>

<script>
import { fetchProductCateList, delCategory } from "@/api/product.js";
export default {
  name: "productCate",
  data: function () {
    return {
      cateList: [],
      listQuery: {
        pageSize: 10, //默认每页显示10条
        pageNum: 1, //默认当前页是第一页
      },
      total: null,
      parent_id: 0,
    };
  },
  // created() {
  //   fetchProductCateList().then((res) => {
  //     console.log(res);
  //     this.cateList = res.data;
  //   });
  // },
  //async await  generator 的语法糖，可以将异步操作转同步操作
  created() {
    // var res = await fetchProductCateList();
    // this.cateList = res.data;
    // console.log(res,"from create");
    this.getProductCateList();
  },
  filters: {
    // label=级别
    levelF: function (value) {
      return value ? "二级" : "一级";
    },
  },
  methods: {
    //from index.vue to add.vue
    delCategory: function (id) {
      console.log(id);
      //1.删除前需要提示
      this.$confirm("此操作将永久删除该条商品数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          delCategory({ id: id }).then((res) => {
            // console.log(res);
            if (res.type == "success") {
              this.$message({
                type: "success",
                message: "删除成功!",
                duration: 2000,
              });

              this.getProductCateList();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
            duration: 2000,
          });
        });
    },
    goAdd() {
      this.$router.push("/pms/productCateAdd");
    },
    getProductCateList: async function () {
      //分页的数据需要传到 后台
      var res = await fetchProductCateList(this.listQuery, this.parent_id);
      this.cateList = res.data;
      this.total = res.total; //总条数
    },
    handleSizeChange(val) {
      console.log("修改页面条数的函数运行了", val);
      this.listQuery.pageSize = val;
      this.listQuery.pageNum = 1;
      //获取数据
      this.getProductCateList();
    },
    //修改当前页的页码
    handleCurrentChange(val) {
      console.log("修改当前页的页码的函数运行了", val);
      //将页码信息 保存到  listQuery
      this.listQuery.pageNum = val;
      //再次获取数据
      this.getProductCateList();
    },
    //查看下级
    showNextLevel: function (id) {
      this.parent_id = id;
      console.log(id, "index---showNExtLevel()");
      //重新获取数据
      this.getProductCateList();
    },
    //返回上一级
    goParentLevel: function () {
      this.parent_id = 0;
      //重新获取数据
      this.getProductCateList();
    },
    updateProductCate(id) {
      console.log(id);
      this.$router.push("/pms/updateProductCate/" + id);
    },
    delProduct() {},
  },
};
</script>

<style scoped lang='scss'>
.pro_con {
  padding: 10px;
  .box-card {
    margin-bottom: 10px;
  }
  .goBack {
    margin-right: 15px;
  }
}
</style>