import { Login } from "@/api/user.js";
import { removeCookie, setCookie } from "../../utils/support";
import { getCookie } from "../../utils/support";
import md5 from "js-md5";

const user = {
  state: {
    name: getCookie("name") || "",
    roleid: getCookie("roleid") || "",
  },
  mutations: {
    SET_NAME: (state, name) => {
      state.name = name;
    },
    SET_ROlEID: (state, roleid) => {
      state.roleid = roleid;
    },
  },
  actions: {
    LOGIN_AC: ({ commit }, userInfo) => {
      return new Promise((resolve) => {
        const { username, password } = userInfo;
        console.log(md5(password));
        console.log(username);
        userInfo.password = md5(password + md5(password).substr(10, 10) + 2014);
        Login(userInfo).then((res) => {
          console.log(res);
          // cookie的参数 key  键  value 值   expires 过期时间
          setCookie("token", res["token"], 1);
          setCookie("name", res["name"], 1);
          setCookie("roleid", res["roleid"], 1);
          setCookie("username", res["username"], 1);
          //设置store  最后由promise resolve 带回数据
          commit("SET_NAME", res["name"]); /*  */
          commit("SET_ROlEID", res["roleid"]);
          resolve(res);
        });
      });
    },
    LOGOUT_AC: ({commit}) => {
      //设置store
      commit("SET_NAME", "");
      commit("SET_ROlEID", "");
      //清楚cookie
      removeCookie("token");
      removeCookie("name");
      removeCookie("roleid");
      removeCookie("username");
    },
  },
};

export default user;
