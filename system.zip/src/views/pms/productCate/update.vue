<template>
  <div>
    <el-card class="box-card">
      <div class="clearfix">
        <span><i class="iconfont icon-dingdan1"> </i>修改商品分类</span>
        <router-link to="/pms/productCate"
          ><el-button style="float: right" type="primary" size="small"
            >返回商品分类</el-button
          ></router-link
        >
      </div>

      <el-form
        :model="listQuery"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="上级分类:" prop="name">
          <el-input v-model="listQuery.name"></el-input>
        </el-form-item>
        <el-form-item label="数量单位:" prop="name">
          <el-input v-model="listQuery.product_unit"></el-input>
        </el-form-item>
        <el-form-item label="排序:" prop="name">
          <el-input v-model="listQuery.sort"></el-input>
        </el-form-item>
        <el-form-item label="是否显示:" prop="name">
          <!-- <el-input v-model="listQuery.sort"></el-input> -->

          <el-radio-group v-model="listQuery.show_status">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="关键词:" prop="name">
          <el-input v-model="listQuery.keywords"></el-input>
        </el-form-item>
        <el-form-item label="分类描述:" prop="name">
          <el-input v-model="listQuery.description"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')"
            >立即创建</el-button
          >
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
// import { updateProductCate,productCateOne } from "@/api/product.js";
import { productCateOne, updateProductCate } from "@/api/product.js";
export default {
  name: "updateProductCate",
  data() {
    return {
      listQuery: {
        description: "", //描述
        icon: "", //小图标
        keywords: "", //关键词
        name: "", //名称
        nav_status: 0, //是否显示在导航
        parent_id: 0, //上级节点id
        product_unit: "", //数量单位
        product_count: 0, //商品数量
        show_status: 0, //是否显示
        sort: 0, //排序
        level: 0, //0表示一级分类 1表示二级分类
      },
      categoryOptions: [],
      rules: {},
    };
  },
  filter: {
    verify: function (value) {
      return value ? "已审核" : "未审核";
    },
  },
  created() {
    productCateOne({ id: this.$route.params.id }).then((res) => {
      console.log(res);
      this.listQuery = res.data;
      console.log(this.listQuery);
    });
  },
  methods: {
    submitForm(formName) {
      console.log("表单提交了");
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //调用后台接口将数据传给 服务器，生成一条新的数据
          updateProductCate(this.listQuery).then((res) => {
            console.log(res);
            if (res.msg == "修改成功") {
              this.$message({
                message: "成功修改商品",
                duration: 1000,
                type: "success",
              });
              this.$router.push("/pms/productCate");
            }
          });
        } else {
          console.log("表单验证没通过");
          return false;
        }
      });
    },
    handleChange() {},
    getProductCate() {
      // updateProductCate().then((res) => {
      // });
    },
  },
  components: {},
};
</script>

<style>
</style>