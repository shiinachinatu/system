<template>
  <!-- 品牌管理 -->
  <div>
    <!-- table star -->
    <el-table :data="brandList" border style="width: 100%" class="listtable">
      <el-table-column prop="id" label="编号" width="180"> </el-table-column>

      <el-table-column label="商品图片" width="180">
        <template slot-scope="scope"><img :src="scope.row.logo" /> </template>
      </el-table-column>

      <el-table-column label="是否显示">
        <template slot-scope="scope">
          <el-switch
            class="slectBtn"
            v-model="scope.row.show_status"
            :active-value="1"
            :inactive-value="0"
          >
          </el-switch>
        </template>
      </el-table-column>

      <el-table-column prop="name" label="商品名称" width="180">
      </el-table-column>
    </el-table>
    <!-- table end -->
    <!-- fenye star -->
    <!-- 分页器 
    size-change 修改每页显示的条数
    current-change 修改当前页页码
    current-page 当前的页码  默认 给他一个1
    page-sizes  当前的每页数据  ，能够切换
    page-size  当前每页有多少条
    total    数据的总条数
    -->

      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="brandPage.pageNum"
        :page-sizes="[3, 6, 9, 12,13]"
        :page-size="brandPage.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
  </div>
</template>

<script>
// import axios from "axios";
import { fetchBrandList } from "@/api/product.js";
export default {
  name: "brand",
  data() {
    return {
      brandList: [],
      value: true,
      brandPage: {
        pageSize: 6,
        pageNum: 1,
      },
      total:0,
    };
  },
  created() {
     this.getBrand();
  },
  methods: {
    getBrand() {
      fetchBrandList(this.brandPage).then((res) => {
        this.brandList = res.data;
        this.total = res.total;
        // console.log(this.brandList);
        // console.log(this.listQuery);
      });
    },
    handleSizeChange(v) {
      console.log("显示", v, "页data");
      this.brandPage.pageSize = v;
      this.brandPage.pageNum = 1;
      //获取数据
      this.getBrand();
    },
    handleCurrentChange(v) {
      // console.log(v);
      this.brandPage.pageNum = v;
      //再次获取数据
      this.getBrand();
    },
  },
};
</script>

<style>
img {
  width: 50px;
}
.cell {
  display: inline;
}
</style>