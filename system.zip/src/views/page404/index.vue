<template>
  <div>404页</div>
</template>
<script>
export default {
  name: "page404",
  data() {
    return {};
  },
};
</script>
<style scoped>
</style>